# Guardify - Privacy Guard Android App

A comprehensive mobile security application that helps users audit installed apps, monitor permissions, and detect potential privacy threats.

## 📱 Features

### ✅ Implemented Features

#### 1. **User Authentication**
- Email/Password login and registration
- Google Sign-In integration
- Secure Firebase Authentication

#### 2. **Onboarding Flow**
- Permission explanation screen
- SMS permission request for scam detection (optional)
- App scanning permission (automatic on Android 11+)

#### 3. **Home Dashboard**
- Quick scan summary with risk counts
- One-tap device scanning
- Quick action buttons

#### 4. **App Audit**
- **Real-time scanning** of all installed applications
- **Permission analysis** for each app
- **Risk classification:**
  - 🔴 **High Risk**: 3+ sensitive permissions + internet + dangerous permissions (SMS, Call Log, Background Location)
  - 🟡 **Medium Risk**: 1-2 sensitive permissions OR storage + internet
  - 🟢 **Low Risk**: No sensitive permissions
- **Search functionality** to find specific apps
- **Filter by risk level**

#### 5. **App Details**
- View all permissions for any app
- **Exodus Privacy API integration** for tracker detection
- Direct link to system settings to manage permissions
- One-tap uninstall option

#### 6. **Bottom Navigation**
- Home
- Audit
- Alerts (placeholder for SMS scam detection)
- Settings

#### 7. **Settings**
- User profile display
- Logout functionality

---

## 🛠 Setup Instructions

### Prerequisites
- Android Studio (Arctic Fox or newer)
- macOS, Windows, or Linux
- JDK 11 or newer

### Step 1: Open in Android Studio
1. Open Android Studio
2. Select **File > Open**
3. Navigate to the `Guardify` folder and open it
4. Wait for Gradle sync to complete

### Step 2: Replace google-services.json
**IMPORTANT:** Replace the placeholder `app/google-services.json` with your own from Firebase Console.

Your Firebase project must have:
- Package name: `com.uow.guardify`
- Email/Password authentication enabled
- Google Sign-In enabled (with SHA-1 fingerprint added)

### Step 3: Add SHA-1 for Google Sign-In
Run this command in Terminal:
```bash
keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android
```

Copy the SHA-1 fingerprint and add it to:
**Firebase Console > Project Settings > Your App > Add Fingerprint**

### Step 4: Build and Run
1. Connect an Android device or start an emulator (API 26+)
2. Click **Run** ▶️
3. Grant permissions when prompted

---

## 📁 Project Structure

```
app/src/main/
├── java/com/uow/guardify/
│   ├── adapter/
│   │   ├── AppListAdapter.kt      # RecyclerView adapter for app list
│   │   ├── PermissionAdapter.kt   # Adapter for permission list
│   │   └── TrackerAdapter.kt      # Adapter for tracker list
│   ├── api/
│   │   ├── ExodusApiService.kt    # Exodus Privacy API interface
│   │   └── RetrofitClient.kt      # Retrofit singleton
│   ├── model/
│   │   ├── AppInfo.kt             # App data model with risk calculation
│   │   └── TrackerInfo.kt         # Tracker data models
│   ├── ui/
│   │   ├── home/HomeFragment.kt   # Home dashboard
│   │   ├── audit/AuditFragment.kt # App audit list
│   │   ├── alerts/AlertsFragment.kt # Alerts (placeholder)
│   │   └── settings/SettingsFragment.kt # Settings
│   ├── util/
│   │   ├── AppScanner.kt          # Scans installed apps
│   │   ├── PermissionHelper.kt    # Permission utilities
│   │   ├── PreferencesManager.kt  # SharedPreferences manager
│   │   └── TrackerRepository.kt   # Exodus API handler
│   ├── LoginActivity.kt           # Login screen
│   ├── OnboardingActivity.kt      # Permission onboarding
│   ├── MainActivity.kt            # Main navigation host
│   └── AppDetailActivity.kt       # App detail screen
└── res/
    ├── layout/                    # XML layouts
    ├── drawable/                  # Icons and backgrounds
    ├── values/                    # Colors, strings, themes
    └── menu/                      # Navigation menu
```

---

## 🔒 Permissions Used

| Permission | Purpose |
|------------|---------|
| `INTERNET` | Firebase auth & Exodus API |
| `QUERY_ALL_PACKAGES` | List all installed apps |
| `READ_SMS` (optional) | Scan messages for scam links |
| `RECEIVE_SMS` (optional) | Monitor incoming messages |

---

## 🔴 Risk Classification Logic

```kotlin
High Risk = (sensitivePermissions >= 3 && hasInternet && hasHighRiskPermission)
Medium Risk = (sensitivePermissions >= 2 && hasInternet) || sensitivePermissions >= 1
Low Risk = Everything else

// High Risk Permissions:
- READ_SMS, SEND_SMS
- READ_CALL_LOG
- ACCESS_BACKGROUND_LOCATION
- RECORD_AUDIO
- CAMERA
```

---

## 📡 Exodus Privacy API

The app uses the [Exodus Privacy API](https://reports.exodus-privacy.eu.org/api/) to detect trackers in apps.

**Endpoints used:**
- `GET /api/search/{package_name}/details` - Get tracker report for an app
- `GET /api/trackers` - Get all known trackers

---

## 🎨 Design

The app follows the dark theme design provided in the reference HTML mockups:
- Background: `#101922`
- Cards: `#161E2C`
- Primary: `#2B8CEE`
- High Risk: `#EF4444`
- Medium Risk: `#F59E0B`
- Low Risk: `#10B981`

---

## ⚠️ Known Limitations

1. **Cannot revoke permissions programmatically** - Android security model requires user to manually manage permissions in Settings
2. **Tracker detection requires internet** - Exodus API must be reachable
3. **SMS scanning** - Requires explicit user permission and may trigger Play Store review

---

## 🔜 Future Enhancements

- [ ] SMS scam detection with ML
- [ ] Real-time permission monitoring
- [ ] Network traffic analysis
- [ ] Push notifications for security alerts
- [ ] Export security reports

---

## 📄 License

This project is for educational purposes as part of a graduation project.

---

## 👨‍💻 Author

Created with ❤️ for UOW Graduation Project
