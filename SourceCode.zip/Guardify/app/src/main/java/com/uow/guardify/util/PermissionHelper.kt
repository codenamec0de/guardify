package com.uow.guardify.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

object PermissionHelper {
    
    // Get human-readable permission name
    fun getPermissionName(permission: String): String {
        return when {
            permission.contains("CAMERA") -> "Camera"
            permission.contains("RECORD_AUDIO") || permission.contains("MICROPHONE") -> "Microphone"
            permission.contains("LOCATION") -> "Location"
            permission.contains("CONTACTS") -> "Contacts"
            permission.contains("SMS") -> "SMS"
            permission.contains("CALL_LOG") -> "Call Log"
            permission.contains("PHONE") -> "Phone"
            permission.contains("CALENDAR") -> "Calendar"
            permission.contains("STORAGE") || permission.contains("MEDIA") -> "Storage"
            permission.contains("SENSORS") -> "Sensors"
            permission.contains("ACTIVITY") -> "Activity Recognition"
            permission.contains("BLUETOOTH") -> "Bluetooth"
            permission.contains("WIFI") -> "Wi-Fi"
            permission.contains("INTERNET") -> "Internet"
            permission.contains("NOTIFICATION") -> "Notifications"
            permission.contains("BIOMETRIC") || permission.contains("FINGERPRINT") -> "Biometrics"
            else -> permission.substringAfterLast(".").replace("_", " ").lowercase()
                .replaceFirstChar { it.uppercase() }
        }
    }
    
    // Get permission description
    fun getPermissionDescription(permission: String): String {
        return when {
            permission.contains("CAMERA") -> "Take photos and record videos"
            permission.contains("RECORD_AUDIO") -> "Record audio using the microphone"
            permission.contains("ACCESS_FINE_LOCATION") -> "Access your precise GPS location"
            permission.contains("ACCESS_COARSE_LOCATION") -> "Access your approximate location"
            permission.contains("ACCESS_BACKGROUND_LOCATION") -> "Access location while in background"
            permission.contains("READ_CONTACTS") -> "Read your contacts list"
            permission.contains("WRITE_CONTACTS") -> "Modify your contacts"
            permission.contains("READ_SMS") -> "Read your text messages"
            permission.contains("SEND_SMS") -> "Send SMS messages"
            permission.contains("RECEIVE_SMS") -> "Receive SMS messages"
            permission.contains("READ_CALL_LOG") -> "View your call history"
            permission.contains("CALL_PHONE") -> "Make phone calls directly"
            permission.contains("READ_CALENDAR") -> "Read calendar events"
            permission.contains("WRITE_CALENDAR") -> "Create or modify calendar events"
            permission.contains("READ_EXTERNAL_STORAGE") -> "Access photos, media, and files"
            permission.contains("WRITE_EXTERNAL_STORAGE") -> "Modify or delete files"
            permission.contains("INTERNET") -> "Full network access"
            permission.contains("READ_PHONE_STATE") -> "Read phone status and identity"
            permission.contains("BODY_SENSORS") -> "Access body sensor data"
            permission.contains("ACTIVITY_RECOGNITION") -> "Recognize physical activity"
            else -> "Access ${getPermissionName(permission).lowercase()}"
        }
    }
    
    // Check if permission is sensitive/dangerous
    fun isSensitivePermission(permission: String): Boolean {
        val sensitiveKeywords = listOf(
            "CAMERA", "RECORD_AUDIO", "LOCATION", "CONTACTS", "SMS", 
            "CALL_LOG", "PHONE", "CALENDAR", "STORAGE", "MEDIA",
            "SENSORS", "ACTIVITY", "BIOMETRIC", "FINGERPRINT"
        )
        return sensitiveKeywords.any { permission.contains(it) }
    }
    
    // Open app settings
    fun openAppSettings(context: Context, packageName: String) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
    
    // Open app permission settings directly
    fun openAppPermissionSettings(context: Context, packageName: String) {
        try {
            // Try to open the specific permission settings
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", packageName, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback to general app settings
            openAppSettings(context, packageName)
        }
    }
    
    // Uninstall app
    fun uninstallApp(context: Context, packageName: String) {
        val intent = Intent(Intent.ACTION_DELETE).apply {
            data = Uri.fromParts("package", packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
    
    // Get permission icon resource
    fun getPermissionIcon(permission: String): String {
        return when {
            permission.contains("CAMERA") -> "camera"
            permission.contains("RECORD_AUDIO") -> "mic"
            permission.contains("LOCATION") -> "location_on"
            permission.contains("CONTACTS") -> "contacts"
            permission.contains("SMS") -> "sms"
            permission.contains("CALL") -> "call"
            permission.contains("PHONE") -> "phone"
            permission.contains("CALENDAR") -> "calendar_today"
            permission.contains("STORAGE") || permission.contains("MEDIA") -> "folder"
            permission.contains("SENSORS") -> "sensors"
            permission.contains("INTERNET") -> "wifi"
            permission.contains("BLUETOOTH") -> "bluetooth"
            permission.contains("NOTIFICATION") -> "notifications"
            else -> "security"
        }
    }
}
