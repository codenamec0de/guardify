# Guardify - App Auditor UI
## Your Apps, Your Control

This is the complete UI implementation for the Guardify App Auditor project based on your design prototypes.

---

## 🎨 Design Features

✅ **Dark Theme** with vibrant color highlights (Purple, Blue, Teal)
✅ **Login Screen** with Google, Facebook, and Email options
✅ **Dashboard** with security score and risk overview
✅ **App List** with color-coded risk levels (High/Medium/Low)
✅ **App Detail** with Simple and Expert viewing modes
✅ **Alerts Screen** with notification list
✅ **Settings Screen** with profile and preferences
✅ **Material 3 Design** with Jetpack Compose
✅ **Smooth Navigation** between all screens

---

## 📁 Project Structure

```
com.guardify.appauditor/
├── MainActivity.kt              # Main entry point with navigation
├── ui/
│   ├── theme/
│   │   ├── Color.kt            # Color definitions
│   │   ├── Theme.kt            # Theme configuration
│   │   └── Typography.kt       # Text styles
│   └── screens/
│       ├── LoginScreen.kt      # Login with social auth
│       ├── DashboardScreen.kt  # Main dashboard
│       ├── AppListScreen.kt    # App audit list
│       ├── AppDetailScreen.kt  # Detailed app report
│       ├── AlertsScreen.kt     # Notifications
│       └── SettingsScreen.kt   # User settings
```

---

## 🚀 Setup Instructions

### Step 1: Create New Android Studio Project

1. Open **Android Studio**
2. Click **File** → **New** → **New Project**
3. Select **Empty Activity** (Compose)
4. Configure:
   - **Name:** Guardify
   - **Package name:** com.guardify.appauditor
   - **Save location:** Choose your location
   - **Language:** Kotlin
   - **Minimum SDK:** API 24 (Android 7.0)
   - **Build configuration language:** Kotlin DSL (build.gradle.kts)
5. Click **Finish**

### Step 2: Replace build.gradle.kts

1. Open `app/build.gradle.kts`
2. Replace the entire content with the provided `build.gradle.kts` file
3. Click **Sync Now** at the top

### Step 3: Create Package Structure

In `app/src/main/java/com/guardify/appauditor/`, create:

```
com.guardify.appauditor/
├── MainActivity.kt
└── ui/
    ├── theme/
    │   ├── Color.kt
    │   ├── Theme.kt
    │   └── Typography.kt
    └── screens/
        ├── LoginScreen.kt
        ├── DashboardScreen.kt
        ├── AppListScreen.kt
        ├── AppDetailScreen.kt
        ├── AlertsScreen.kt
        └── SettingsScreen.kt
```

### Step 4: Copy All Kotlin Files

Copy the content of each provided `.kt` file into the corresponding files in your project:

1. **MainActivity.kt** → `app/src/main/java/com/guardify/appauditor/MainActivity.kt`

2. **Theme Files:**
   - Color.kt → `ui/theme/Color.kt`
   - Theme.kt → `ui/theme/Theme.kt`
   - Typography.kt → `ui/theme/Typography.kt`

3. **Screen Files:**
   - LoginScreen.kt → `ui/screens/LoginScreen.kt`
   - DashboardScreen.kt → `ui/screens/DashboardScreen.kt`
   - AppListScreen.kt → `ui/screens/AppListScreen.kt`
   - AppDetailScreen.kt → `ui/screens/AppDetailScreen.kt`
   - AlertsScreen.kt → `ui/screens/AlertsScreen.kt`
   - SettingsScreen.kt → `ui/screens/SettingsScreen.kt`

### Step 5: Update AndroidManifest.xml (if needed)

The manifest should already be correct, but ensure it matches the provided `AndroidManifest.xml`

### Step 6: Build and Run

1. Click **Build** → **Rebuild Project**
2. Wait for the build to complete
3. Click the **Run** button (green play icon)
4. Select your emulator or connected device
5. The app should launch with the Login screen

---

## 🎯 Navigation Flow

```
Login Screen
    ↓
Dashboard (Security Score, Quick Actions)
    ↓
    ├─→ App List (Search, Filter by Risk)
    │       ↓
    │   App Detail (Simple/Expert Mode)
    │
    ├─→ Alerts (Notifications)
    │
    └─→ Settings (Profile, Preferences)
```

---

## 🎨 Color Scheme

- **Background:** `#121212` (Dark)
- **Surface:** `#1E1E1E` (Card backgrounds)
- **Primary:** `#8B5CF6` (Purple)
- **Secondary:** `#3B82F6` (Blue)
- **Tertiary:** `#14B8A6` (Teal)

**Risk Colors:**
- **High Risk:** `#EF4444` (Red)
- **Medium Risk:** `#F59E0B` (Orange)
- **Low Risk:** `#10B981` (Green)
- **No Risk:** `#6B7280` (Gray)

---

## 📱 Screen Previews

### Login Screen
- Google, Facebook, and Email login options
- Gradient logo with "G" initial
- Professional tagline

### Dashboard
- Security score (72/100) in circular badge
- Quick stats: High Risk (8), Medium (15), Low (42)
- Quick action buttons with icons

### App List
- Search bar with filter
- Risk level filter chips (All, High, Medium, Low)
- Each app shows: Icon, Name, Permission count, Tracker count, Risk badge

### App Detail
- App header with risk badge
- Stats cards: Permissions, Trackers, Rating
- Toggle between Simple and Expert modes
- **Simple Mode:** Risk summary with bullet points
- **Expert Mode:** Detailed permission cards with descriptions

### Alerts
- List of security notifications
- Color-coded by severity (Critical, Warning, Info)
- Timestamp and app name for each alert

### Settings
- User profile card
- Premium upgrade banner
- Toggle switches for notifications, auto-scan, tracker detection
- About section with version info
- Logout button

---

## 🔧 Customization

### Change Colors
Edit `ui/theme/Color.kt` to modify the color scheme

### Modify Text Styles
Edit `ui/theme/Typography.kt` to change fonts and sizes

### Add New Screens
1. Create new file in `ui/screens/`
2. Add composable function
3. Add route in `MainActivity.kt` NavHost

---

## 📦 Dependencies Used

- **Jetpack Compose** - Modern UI toolkit
- **Material 3** - Latest Material Design components
- **Navigation Compose** - Screen navigation
- **Material Icons Extended** - Rich icon set

---

## ⚠️ Notes

- This is **UI only** - no real functionality yet
- All data is **dummy/mock data** for visualization
- Icons use Material Icons (built-in)
- No API calls or database connections

---

## 🎓 Next Steps

To add functionality:
1. Implement PackageManager API for real app scanning
2. Add permission risk classification logic
3. Integrate OWASP/NIST mappings
4. Implement Settings deep-links
5. Add CSV/JSON export functionality
6. Connect to Exodus API for tracker detection

---

## 💡 Tips

- Use **Android Studio Preview** to see composables without running
- Press **Ctrl+Shift+P** (Windows) or **Cmd+Shift+P** (Mac) in Compose files
- If build fails, try **File → Invalidate Caches → Restart**
- Make sure you're using **Java 8** or higher

---

## 📞 Support

If you encounter issues:
1. Check that all imports are correct (Android Studio will auto-import)
2. Ensure Gradle sync completed successfully
3. Verify you're using minimum SDK 24
4. Clean and rebuild: **Build → Clean Project** → **Build → Rebuild Project**

---

**Built with ❤️ using Jetpack Compose**
